from django.contrib import admin
from django.urls import path, include


# Para servir archivos media en desarrollo
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('noticias.urls')),
]

# Sirve archivos media solo si DEBUG está activado (desarrollo)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
