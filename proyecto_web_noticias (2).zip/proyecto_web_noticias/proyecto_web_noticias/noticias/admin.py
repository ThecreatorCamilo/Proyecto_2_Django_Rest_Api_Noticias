from django.contrib import admin
from .models import Noticia, Etiqueta

# Register your models here.
admin.site.register(Noticia)
admin.site.register(Etiqueta)