import django_filters
from .models import Noticia

class NoticiaFilter(django_filters.FilterSet):
    fecha_inicio = django_filters.DateFilter(field_name='fecha_publicacion', lookup_expr='gte')
    fecha_fin = django_filters.DateFilter(field_name='fecha_publicacion', lookup_expr='lte')
    min_popularidad = django_filters.NumberFilter(field_name='popularidad', lookup_expr='gte')
    max_popularidad = django_filters.NumberFilter(field_name='popularidad', lookup_expr='lte')

    class Meta:
        model = Noticia
        fields = ['categoria', 'fecha_inicio', 'fecha_fin', 'min_popularidad', 'max_popularidad']
