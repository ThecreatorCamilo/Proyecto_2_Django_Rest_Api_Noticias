from django.db import models
from django.contrib.auth.models import User


class Etiqueta(models.Model):
    """
    Modelo para etiquetas asociadas a las noticias.
    """
    nombre = models.CharField(max_length=50, unique=True)

    class Meta:
        verbose_name = 'Etiqueta'
        verbose_name_plural = 'Etiquetas'
        ordering = ['nombre']

    def __str__(self):
        return self.nombre


class Noticia(models.Model):
    """
    Modelo principal de Noticia.
    """
    CATEGORIAS = [
        ('politica', 'Política'),
        ('deportes', 'Deportes'),
        ('economia', 'Economía'),
        ('cultura', 'Cultura'),
        ('tecnologia', 'Tecnología'),
        ('musica', 'Musica'),
        ('farandula', 'Farandula')
    ]

    titulo = models.CharField(max_length=200)
    contenido = models.TextField()
    categoria = models.CharField(max_length=50, choices=CATEGORIAS)
    etiquetas = models.ManyToManyField(Etiqueta, blank=True)
    fecha_publicacion = models.DateField()
    autor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='noticias')
    popularidad = models.PositiveIntegerField(default=0)
    imagen = models.ImageField(upload_to='noticias/', blank=True, null=True)

    class Meta:
        verbose_name = 'Noticia'
        verbose_name_plural = 'Noticias'
        ordering = ['-fecha_publicacion']

    def __str__(self):
        return self.titulo

    def resumen(self):
        """
        Devuelve un resumen de los primeros 100 caracteres del contenido.
        """
        return self.contenido[:100] + '...' if len(self.contenido) > 100 else self.contenido
