from rest_framework import serializers
from .models import Noticia, Etiqueta
from django.contrib.auth.models import User

class EtiquetaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Etiqueta
        fields = ['id', 'nombre']


class NoticiaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Noticia
        fields = '__all__'

class NoticiaCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Noticia
        # 'autor' no debe venir del frontend, se asigna con perform_create
        exclude = ['autor']

