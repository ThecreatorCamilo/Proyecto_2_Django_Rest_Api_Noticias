from django.urls import path
from .views import (
    NoticiaListView, NoticiaCreateView, NoticiaUpdateView,
    NoticiaDeleteView, NoticiaDetailView
)

urlpatterns = [
    path('noticias/', NoticiaListView.as_view(), name='noticia-list'),
    path('noticias/crear/', NoticiaCreateView.as_view(), name='noticia-create'),
    path('noticias/<int:pk>/', NoticiaDetailView.as_view(), name='noticia-detail'),
    path('noticias/<int:pk>/editar/', NoticiaUpdateView.as_view(), name='noticia-update'),
    path('noticias/<int:pk>/eliminar/', NoticiaDeleteView.as_view(), name='noticia-delete'),
]
