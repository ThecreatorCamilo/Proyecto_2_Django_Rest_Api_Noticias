from rest_framework import generics, permissions
from rest_framework.exceptions import PermissionDenied
from .models import Noticia, Etiqueta
from .serializers import NoticiaSerializer, NoticiaCreateUpdateSerializer
from .filters import NoticiaFilter
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from .pagination import CustomPagination
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from rest_framework.permissions import IsAuthenticated

class NoticiaListView(generics.ListAPIView):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaSerializer
    pagination_class = CustomPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter, SearchFilter]
    filterset_class = NoticiaFilter
    
    ordering_fields = ['fecha_publicacion', 'popularidad']
    search_fields = ['titulo', 'contenido']

CATEGORIAS_ETIQUETAS = {
    'politica': [
        'elecciones', 'gobierno', 'democracia', 'partidos',
        'leyes', 'corrupción', 'política internacional'
    ],
    'deportes': [
        'fútbol', 'olimpiadas', 'jugadores', 'ligas',
        'campeonatos', 'estadios', 'récords'
    ],
    'economia': [
        'mercado', 'inflación', 'empleo', 'banca',
        'impuestos', 'PIB', 'finanzas'
    ],
    'cultura': [
        'arte', 'literatura', 'música', 'cine',
        'teatro', 'tradiciones', 'historia'
    ],
    'tecnologia': [
        'innovación', 'internet', 'IA', 'software',
        'hardware', 'ciberseguridad', 'startups'
    ],
    'musica': [
        'álbumes', 'cantantes', 'conciertos', 'géneros',
        'instrumentos', 'notas musicales', 'bandas'
    ],
    'farandula': [
        'celebridades', 'rumores', 'entrevistas', 'premios',
        'series', 'películas', 'moda'
    ],
}

class NoticiaCreateView(generics.CreateAPIView):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaCreateUpdateSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        noticia = serializer.save(autor=self.request.user)
        categoria = noticia.categoria

        etiquetas_nombres = CATEGORIAS_ETIQUETAS.get(categoria, [])
        etiquetas_objs = []

        for nombre in etiquetas_nombres:
            etiqueta, _ = Etiqueta.objects.get_or_create(nombre=nombre)
            etiquetas_objs.append(etiqueta)

        noticia.etiquetas.add(*etiquetas_objs)  # Las suma a las ya existentes si el usuario añadió alguna manualmente

class NoticiaUpdateView(generics.RetrieveUpdateAPIView):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaCreateUpdateSerializer
    permission_classes = [AllowAny]

    def perform_update(self, serializer):
        instance = serializer.save()
        categoria = instance.categoria
        etiquetas_nombres = CATEGORIAS_ETIQUETAS.get(categoria, [])

        nuevas_etiquetas = []
        for nombre in etiquetas_nombres:
            etiqueta, created = Etiqueta.objects.get_or_create(nombre=nombre)
            nuevas_etiquetas.append(etiqueta)

        instance.etiquetas.set(nuevas_etiquetas)


class NoticiaDeleteView(generics.RetrieveDestroyAPIView):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaSerializer
    pagination_class = CustomPagination
    permission_classes = [AllowAny]
    
class NoticiaDetailView(generics.RetrieveAPIView):
    queryset = Noticia.objects.all()
    serializer_class = NoticiaSerializer
